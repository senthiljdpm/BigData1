package mapred_dna3a;

import java.io.IOException;
import java.util.Arrays;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DNAMapper3a extends Mapper<Object, Text, Text, LongWritable> 
{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		String[] dna = new String[]	{"User1 ACGT","User2 TGCA","User3 ACG", "User4 ACGT","User5 ACG","User6 AGCT"};
		
		for (int i=0; i<dna.length;i++)
		{
		  	String[] spl_i=dna[i].split(" ");
		  		  	
			String temp="";
		  	for (int j=0;j<dna.length;j++)
		  	{
		  		String[] spl_j=dna[j].split(" ");
		  			  		
		  		if(spl_i[1].equals(spl_j[1]) ) 
				{
						temp = temp + "," + spl_j[0];
						dna[j]="% %";
				}
		  	}
		  	temp=temp.substring(1);
		  	if (temp.indexOf("%")==-1)	  			
			  		context.write(new Text(temp), new LongWritable(1));
		  }
	}
}
